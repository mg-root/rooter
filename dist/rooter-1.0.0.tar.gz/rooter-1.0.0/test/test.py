from rooter import rooter, print, clear, exit
from rooter import getLengthWithoutTags

# function: print
text = "It's my package <yellow>python</>."
print(text)

# function: getLengthWithoutTags
# print(getLengthWithoutTags(text))

# function: clear
# clear()

# function: exit
# exit()